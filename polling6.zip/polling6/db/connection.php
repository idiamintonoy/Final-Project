<?php 
$con = mysqli_connect("localhost","root","","vote1") or die ("error" . mysqli_error($con));
?>
